django-admin startproject HelloWorld
